// POST { query, library: [{id, description}] }
const MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  try {
    const { query, library } = req.body || {};
    if (!query || !Array.isArray(library) || library.length === 0) return res.status(400).json({ error: "Missing query or library" });
    if (!process.env.GEMINI_API_KEY) return res.status(500).json({ error: "GEMINI_API_KEY is not set in Vercel" });

    const index = library.map((p) => `id:${p.id} — ${p.description}`).join("\n");
    const prompt = `A user is trying to find a specific photo from memory using a vague, imprecise description (they don't remember exact dates or exact words). Here is a photo library index:\n\n${index}\n\nUser's query: "${query}"\n\nReturn ONLY JSON: an array of up to 3 objects {"id": "<id>", "reason": "<one short sentence on why this matches>"}, best match first. Return [] if nothing plausibly matches.`;

    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-goog-api-key": process.env.GEMINI_API_KEY },
      body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseMimeType: "application/json" } }),
    });
    if (!r.ok) {
      const detail = await r.text().catch(() => "");
      return res.status(r.status === 429 ? 429 : 502).json({ error: "Gemini API error " + r.status, detail });
    }
    const data = await r.json();
    const raw = ((data.candidates || [])[0]?.content?.parts || []).map((p) => p.text || "").join("");
    let matches = [];
    try { const m = raw.match(/\[[\s\S]*\]/); matches = JSON.parse(m ? m[0] : raw); } catch (e) { matches = []; }
    res.status(200).json({ matches });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
}
